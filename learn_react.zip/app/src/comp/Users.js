import React from 'react';

const Users = () => <div>Users</div>;

export default Users;
