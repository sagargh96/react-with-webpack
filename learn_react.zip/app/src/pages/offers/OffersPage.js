import React, { Component } from 'react';

/*style*/ import './OffersPage.module.scss';

//import { Store } from 'containers';

class OffersPage extends Component {
    render() {
        return (
                <div className='page-wrapper'>
                    <h1>Offer TBD</h1>
                </div>
        );
    }
}

export default OffersPage;