export const signUpInitTexts = {
    signUpFormText: {
        heading: "Create Account",
        subHeading: "",
    },
    zipCodeFormText: {
        headingText: "Buy your groceries online",
        subHeadingText: "10% discount on your first order.",
        submitBtnText: "Find Store"
    },
    signInFormText: {
        headingText: "Login"
    }
};
