export const basePath = '/store';
export const offersPath = '/offers';

export const serverUrl = 'https://limitless-cliffs-82484.herokuapp.com';
//export const serverUrl = 'http://localhost:5000';

export const imagesBasePath = serverUrl + '/resource/images';

const 

