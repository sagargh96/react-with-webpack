export const accountRoles = {
    unverifiedUser: 'ROLE_UNVERIFIED_USER',
    user: 'ROLE_USER',
    admin: 'ROLE_ADMIN'
}