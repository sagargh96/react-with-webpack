## App Component
Top level Application component that sits above other components.

### Props

| Prop          | Type     | Default     | Possible Values   
| ------------- | -------- | ----------- | ---------------------------------------------
| **children** | Element   |             | Any children react components