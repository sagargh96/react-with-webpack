const fetchDefaultStore = (zipCode) => {
    
};